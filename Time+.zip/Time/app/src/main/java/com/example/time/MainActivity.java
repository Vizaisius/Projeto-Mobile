package com.example.time;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    private final ArrayList<HashMap<String, Object>> eventList = new ArrayList<>();
    private LinearLayout linearLayoutEvents;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        linearLayoutEvents = findViewById(R.id.linearLayoutEvents);

        CalendarView calendarView = findViewById(R.id.calendarView);
        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            String selectedDate = dayOfMonth + "/" + (month + 1) + "/" + year;
            openAddEventDialog(selectedDate);
        });
    }

    private void openAddEventDialog(String date) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_add_event, null);

        EditText editTextDescription = dialogView.findViewById(R.id.editTextDescription);
        RatingBar ratingBarUrgency = dialogView.findViewById(R.id.ratingBarUrgency);

        builder.setTitle("Adicionar compromisso")
                .setMessage("Data: " + date)
                .setView(dialogView)
                .setPositiveButton("Salvar", (dialog, which) -> {
                    String description = editTextDescription.getText().toString().trim();
                    int urgency = (int) ratingBarUrgency.getRating();

                    if (!description.isEmpty()) {
                        saveEvent(date, description, urgency);
                        addEventToView("Data: " + date + "\nCompromisso: " + description + "\nUrgência: " + urgency + " estrelas");
                    } else {
                        Toast.makeText(this, "A descrição não pode ser vazia.", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .create()
                .show();
    }

    private void saveEvent(String date, String description, int urgency) {
        HashMap<String, Object> event = new HashMap<>();
        event.put("date", date);
        event.put("description", description);
        event.put("urgency", urgency);
        eventList.add(event);
    }

    private void addEventToView(String eventText) {
        TextView textView = new TextView(this);
        textView.setText(eventText);
        textView.setPadding(8, 8, 8, 8);
        linearLayoutEvents.addView(textView);
    }
}
